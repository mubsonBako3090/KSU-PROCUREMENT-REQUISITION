// placeholder for public/images
